package com.example.finalproject.ui.Schedule

import androidx.lifecycle.ViewModel

class ScheduleViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}