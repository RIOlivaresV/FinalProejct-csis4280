
class Users (
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val password: String = ""
)