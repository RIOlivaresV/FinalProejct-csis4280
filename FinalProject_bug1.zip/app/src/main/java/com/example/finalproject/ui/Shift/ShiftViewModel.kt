package com.example.finalproject.ui.Shift

import androidx.lifecycle.ViewModel

class ShiftViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}