package com.example.finalproject.ui.Employee

import Users
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import io.socket.client.Socket

class EmployeeViewModel : ViewModel() {

}