package com.example.finalproject.ui.CheckIn

import androidx.lifecycle.ViewModel

class CheckInViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}